# Calculate 1/2+1/3 in rational arithmetic using sympy.
import sympy as sym

rational = sym.Rational(1, 2) + sym.Rational(1, 3)
print(rational)
