# Calculate 2with100decimals.

import sympy as sym


root2 = sym.sqrt(2)
print(root2.evalf(100))
