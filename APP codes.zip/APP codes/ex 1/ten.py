n = int(input("Enter a number: "))
m = int(input("Enter a number: "))
sum = n + m
if sum >= 105 and sum <= 200:
    print(200)
else:
    print(sum)
