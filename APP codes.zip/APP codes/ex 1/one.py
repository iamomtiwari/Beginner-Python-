for x in range(1000, 2000):
    if x%8==0 and x%5==0:
        print (x)