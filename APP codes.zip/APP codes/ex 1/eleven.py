for i in range(9, 0, -1):
    print()
    for j in range(i):
        print(i, end=" ")
