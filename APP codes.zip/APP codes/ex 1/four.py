txt = input("Enter a word: ")
rev = txt[::-1]
print(rev)
