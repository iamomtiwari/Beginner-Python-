x = int(input())
y = int(input())

if x == y or x + y == 5 or abs(x - y) == 5:
    print("true")
else:
    print("false")
