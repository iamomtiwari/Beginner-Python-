import sympy

n = int(input("Enter the number: "))
print(sympy.isprime(n))
