str = input()
print(str[::-1])
