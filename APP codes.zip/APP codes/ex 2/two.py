str = input()
l = len(str)
